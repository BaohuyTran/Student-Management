/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AptechApp;

import AptechApp.view.LoginDialog;
import AptechApp.view.MainForm;
import javax.swing.WindowConstants;

/**
 *
 * @author XoaiBuuu
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainForm mf = new MainForm();
        mf.setVisible(true);
    }
    
}
